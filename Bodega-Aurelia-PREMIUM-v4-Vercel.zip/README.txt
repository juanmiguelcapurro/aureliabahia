BODEGA AURELIA — DEMO PREMIUM v4 PARA VERCEL

Sitio estático. No requiere PHP, MySQL ni build.

LOGIN DEMO
Usuario: admin
Contraseña: demo1234

Mejoras v4:
- Botón Admin visible también en mobile.
- Formulario de producto con carga de foto desde computadora o celular.
- Vista previa y opción de quitar/reemplazar foto.
- La foto cargada aparece en la tarjeta del producto en la demo.
- Cambios y fotos de demostración se conservan en el navegador mediante localStorage.
- Footer con crédito enlazado a https://juancapurrodesign.com en pestaña nueva.
- Scroll suave para navegación por secciones.
- Diseño premium, catálogo, filtros, carrito, WhatsApp y formulario.

IMPORTANTE: es una demo de presentación. localStorage no es un sistema multiusuario ni un backend seguro. La versión de producción deberá subir las imágenes a un servidor y guardar productos en una base de datos.
